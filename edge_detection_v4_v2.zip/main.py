# This is a first exercise for Computer Vision program
from tkinter import *
from tkinter import filedialog
from matplotlib import pyplot as plt
from PIL import Image, ImageStat
from math import sqrt, pow, log
import cv2 as cv
import numpy as np

# global variables
filter_image = None
segmentation_image = None
canny_image = None
show_images = True
low_threshold = 255 / 3
high_threshold = 255

# edge detection kernels
# Sobel kernels
sobel_horizontal_kernel = np.array([[-1, 0, 1],
                                    [-2, 0, 2],
                                    [-1, 0, 1]
                                    ])
sobel_vertical_kernel = np.array([[1, 2, 1],
                                  [0, 0, 0],
                                  [-1, -2, -1]
                                  ])
# Prewitt kernels
prewitt_horizontal_kernel = np.array([[-1, 0, 1],
                                      [-1, 0, 1],
                                      [-1, 0, 1]
                                      ])
prewitt_vertical_kernel = np.array([[-1, -1, -1],
                                    [0, 0, 0],
                                    [1, 1, 1]
                                    ])


# key down functions
def click_load_image():
    path = filedialog.askopenfilename()
    img = cv.imread(path, 1)
    if img is None:
        print("Image was not selected")
    else:
        cv.imshow("Image preview", img)
        cv.waitKey(0)
        cv.destroyAllWindows()


# Didn't define the buttons and their functionalities, instead play and pause
# commence with a press of 'P'
def click_load_video():
    # x, y = 0, 0
    path = filedialog.askopenfilename()
    video = cv.VideoCapture(path)
    # play = True
    if video is None:
        print("Video was not selected")
    else:
        while video.isOpened():
            ret, frame = video.read()
            # cv.setMouseCallback("Video", click_image, param=[x, y])
            # if x >= 270 & x <= 310 & y >= 300 & y <= 340:
            #     play = False
            # if x >= 340 & x <= 380 & y >= 300 & y <= 340:
            #     play = True
            # back button
            cv.rectangle(frame, (20, 160), (60, 200), (211, 211, 211), -1)

            # pause button
            cv.rectangle(frame, (270, 300), (310, 340), (211, 211, 211), -1)
            cv.line(frame, (285, 310), (285, 330), (0, 0, 0), 3)
            cv.line(frame, (295, 310), (295, 330), (0, 0, 0), 3)

            # play button
            cv.rectangle(frame, (340, 300), (380, 340), (211, 211, 211), -1)
            cv.line(frame, (352, 310), (352, 330), (0, 0, 0), 3)
            cv.line(frame, (352, 310), (370, 320), (0, 0, 0), 3)
            cv.line(frame, (352, 330), (370, 320), (0, 0, 0), 3)
            # forward button
            cv.rectangle(frame, (580, 160), (620, 200), (211, 211, 211), -1)
            cv.imshow('Video', frame)
            key = cv.waitKey(25)
            # Close the video
            if key == ord('q'):
                break
            # Pause/Play video
            if key == ord('p'):
                cv.waitKey(0)
        video.release()
        cv.destroyAllWindows()


# Didn't define the buttons and their functionalities, instead saving starts and stops
# with a press of 'S'
def click_load_camera():
    camera = cv.VideoCapture(0, cv.CAP_DSHOW)
    width = int(camera.get(cv.CAP_PROP_FRAME_WIDTH) + 0.5)
    height = int(camera.get(cv.CAP_PROP_FRAME_HEIGHT) + 0.5)
    size = (width, height)
    fourcc = cv.VideoWriter_fourcc(*'XVID')
    saving = False
    out = cv.VideoWriter('camera_output.avi', fourcc, 20.0, size)
    if camera is None:
        print("Camera was not opened")
    if not camera.isOpened():
        print("Camera was not able to open")
    while camera.isOpened():
        ret, frame = camera.read()
        cv.imshow("Camera feed", frame)
        key = cv.waitKey(1)
        # Close the camera feed
        if key == ord('q'):
            break
        # Start/Stop saving
        if key == ord('s'):
            saving = not saving
            print("Saving" if saving else "Stopping saving")
        if saving:
            out.write(frame)
    camera.release()
    cv.destroyAllWindows()


# Checking if the image is indeed grayscale
def is_greyscale(img_path):
    image = Image.open(img_path).convert("RGB")
    stat = ImageStat.Stat(image)
    if sum(stat.sum) / 3 == stat.sum[0]:
        return True
    else:
        return False


# Opening images in grayscale mode
def open_image_in_grayscale():
    global filter_image
    cv.destroyAllWindows()
    camera = cv.VideoCapture(1, cv.CAP_DSHOW)
    ret, filter_image = camera.read()
    camera.release()
    filter_image = cv.cvtColor(filter_image, cv.COLOR_BGR2GRAY)
    cv.imshow("Original picture", filter_image)
    open_edge_detection_filters()


# Edge detection algorithms for sobel and prewitt
def apply_edge_detection(image, horizontal_kernel, vertical_kernel):
    image_pixels = np.zeros(image.shape, np.uint8)
    image_edge_direction = np.zeros(image.shape, np.float32)

    horizontal_filtering = np.zeros(image.shape, np.uint8)
    vertical_filtering = np.zeros(image.shape, np.uint8)

    height, width = image.shape

    for x in range(1, height - 1):
        for y in range(1, width - 1):
            horizontal_filtering[x][y] = np.absolute((
                    horizontal_kernel[0][0] * image[x - 1][y - 1] +
                    horizontal_kernel[1][0] * image[x][y - 1] +
                    horizontal_kernel[2][0] * image[x + 1][y - 1] +
                    horizontal_kernel[0][2] * image[x - 1][y + 1] +
                    horizontal_kernel[1][2] * image[x][y + 1] +
                    horizontal_kernel[2][2] * image[x + 1][y + 1]
            ))
            vertical_filtering[x][y] = np.absolute((
                    vertical_kernel[0][0] * image[x - 1][y - 1] +
                    vertical_kernel[0][1] * image[x - 1][y] +
                    vertical_kernel[0][2] * image[x - 1][y + 1] +
                    vertical_kernel[2][0] * image[x + 1][y - 1] +
                    vertical_kernel[2][1] * image[x + 1][y] +
                    vertical_kernel[2][2] * image[x + 1][y + 1]
            ))

            image_pixels[x][y] = sqrt(pow(vertical_filtering[x][y], 2) + pow(horizontal_filtering[x][y], 2))
            if horizontal_filtering[x][y] == 0:
                image_edge_direction[x][y] = 0
            else:
                image_edge_direction[x][y] = np.arctan(vertical_filtering[x][y] / horizontal_filtering[x][y])

    # Display the images with the filters
    if show_images:
        cv.imshow("Horizontal filtering", horizontal_filtering)
        cv.imshow("Vertical filtering", vertical_filtering)
        cv.imshow("Filtered image", image_pixels)
    return image_pixels, image_edge_direction


# Edge detection algorithms
def open_edge_detection_filters():
    filters = Tk()
    filters.title("Filtering")
    filters.configure(background="black", padx=20, pady=20)
    # Buttons for edge detection
    Label(filters, text="Filters", bg="black", fg="white").grid(row=0, column=0)
    Button(filters, text="Sobel", width=30, command=sobel_filter) \
        .grid(row=1, column=0, sticky=N)
    Label(window, bg="black") \
        .grid(row=2, column=0)
    Button(filters, text="Prewitt", width=30, command=prewitt_filter) \
        .grid(row=3, column=0, sticky=N)
    Label(window, bg="black") \
        .grid(row=4, column=0)
    Button(filters, text="Canny", width=30, command=canny) \
        .grid(row=5, column=0, sticky=N)
    filters.mainloop()


# Sobel algorithm for edge detection
def sobel_filter():
    global filter_image, sobel_horizontal_kernel, sobel_vertical_kernel
    apply_edge_detection(filter_image, sobel_horizontal_kernel, sobel_vertical_kernel)


# Prewitt algorithm for edge detection
def prewitt_filter():
    global filter_image, prewitt_horizontal_kernel, prewitt_vertical_kernel
    apply_edge_detection(filter_image, prewitt_horizontal_kernel, prewitt_vertical_kernel)


# Canny algorithm for edge detection
def canny():
    global filter_image, sobel_horizontal_kernel, sobel_vertical_kernel
    reduced_image = noise_reduction(filter_image)
    sobel_power, sobel_direction = apply_edge_detection(reduced_image, sobel_horizontal_kernel, sobel_vertical_kernel)
    shrunk_edges = edge_shrinking(sobel_power, sobel_direction)
    modified_edges = modify_weak_edges_to_strong(shrunk_edges)


# Noise reduction algorithm
def noise_reduction(image):
    noise_reduction_kernel = np.ones((7, 7), np.float32) / 49
    image_pixels = np.zeros(image.shape, np.uint8)

    for x in range(3, image.shape[0] - 3):
        for y in range(3, image.shape[1] - 3):
            sum_kernels = 0
            for i in range(0, 5):
                for j in range(0, 5):
                    offset_i = i - 3
                    offset_j = j - 3
                    sum_kernels = sum_kernels + noise_reduction_kernel[i][j] * image[x - offset_i][y - offset_j]
            image_pixels[x][y] = sum_kernels
    if show_images:
        cv.imshow('Noise reduction', image_pixels)

    return image_pixels


# Edge shrinking and checking the correct directions
def edge_shrinking(sobel_power, sobel_direction):
    shrunk_edges = sobel_power

    for i in range(1, sobel_power.shape[0] - 1):
        for j in range(1, sobel_power.shape[1] - 1):
            if 0 <= sobel_direction[i, j] < 22.5 or 157.5 <= sobel_direction[i, j] <= 180:
                if sobel_power[i, j] <= sobel_power[i, j - 1] or sobel_power[i, j] <= sobel_power[i, j + 1]:
                    shrunk_edges[i, j] = 0
            if 22.5 <= sobel_direction[i, j] < 67.5:
                if sobel_power[i, j] <= sobel_power[i - 1, j + 1] or sobel_power[i, j] <= sobel_power[i + 1, j - 1]:
                    shrunk_edges[i, j] = 0
            if 67.5 <= sobel_direction[i, j] < 112.5:
                if sobel_power[i, j] <= sobel_power[i - 1, j] or sobel_power[i, j] <= sobel_power[i + 1, j]:
                    shrunk_edges[i, j] = 0
            if 112.5 <= sobel_direction[i, j] < 157.5:
                if sobel_power[i, j] <= sobel_power[i - 1, j - 1] or sobel_power[i, j] <= sobel_power[i + 1, j + 1]:
                    shrunk_edges[i, j] = 0
    if show_images:
        cv.imshow('Shrunk edges', shrunk_edges)
    return shrunk_edges


# Change the weak edges to strong ones dependent on thresholds
def modify_weak_edges_to_strong(shrunk_edges):
    global low_threshold, high_threshold
    for i in range(1, shrunk_edges.shape[0] - 1):
        for j in range(1, shrunk_edges.shape[1] - 1):
            if shrunk_edges[i, j] > high_threshold:
                shrunk_edges[i, j] = 255
            elif high_threshold > shrunk_edges[i, j] > low_threshold:
                shrunk_edges[i, j] = 50
    if show_images:
        cv.imshow('Modified edges', shrunk_edges)
    return shrunk_edges


# Graphical interface for image segmentations
def segmentation_graphical_interface():
    global segmentation_image
    # Open image in grayscale
    path = filedialog.askopenfilename()
    segmentation_image = cv.imread(path, cv.IMREAD_GRAYSCALE)
    cv.imshow("Grayscale image", segmentation_image)
    segmentation_gui = Tk()
    segmentation_gui.title("Segmentation")
    segmentation_gui.configure(background="black", padx=20, pady=20)
    # Buttons for edge detection
    Label(segmentation_gui, text="Image segmentation", bg="black", fg="white") \
        .grid(row=0, column=0, columnspan=3, pady=(0, 20))
    Button(segmentation_gui, text="Otsu segmentation", width=20, command=otsu_segmentation) \
        .grid(row=1, column=0, sticky=N)
    Button(segmentation_gui, text="Kapur segmentation", width=20, command=kapur_segmentation) \
        .grid(row=1, column=2, sticky=N, padx=(20, 0))
    segmentation_gui.mainloop()


# Calculate the histogram
def make_histogram(image):
    image_histogram_array = [0] * 256

    for row in image:
        for pixel in row:
            image_histogram_array[pixel] = image_histogram_array[pixel] + 1

    return image_histogram_array


# Calculate the normalized histogram
def make_normalized_histogram(histogram, pixel_count):
    normalized_histogram_array = [0] * 256
    counter = 0

    for value in histogram:
        normalized_histogram_array[counter] = (1 / pixel_count) * value
        counter = counter + 1

    return normalized_histogram_array


# Calculate the array mean
def calculate_array_mean(array):
    array_sum = 0

    for count in range(0, len(array)):
        array_sum += array[count]

    return array_sum / len(array)


# Calculate the variance in array
def calculate_variance(array, pixel_count):
    histogram_sum = 0
    mean = calculate_array_mean(array)

    for count in range(0, len(array)):
        histogram_sum += pow(array[count] - mean, 2)

    return histogram_sum / pixel_count


# Calculate the sum of the threshold
def calculate_sum_threshold(histogram, threshold):
    threshold_sum = 0

    for count in range(0, threshold):
        threshold_sum += histogram[count]

    return threshold_sum


# Calculate variances in thresholds
def calculate_variances_thresholds(histogram, threshold, pixel_count):
    left_threshold_list = list()
    for count in range(0, threshold):
        left_threshold_list.append(histogram[count])

    right_threshold_list = list()
    for count in range(threshold, len(histogram)):
        right_threshold_list.append(histogram[count])

    left_percentage = sum(left_threshold_list) / pixel_count
    # this comment is necessary to suppress an unnecessary PyCharm warning
    # noinspection PyTypeChecker
    left_variance = calculate_variance(left_threshold_list, pixel_count)

    right_percentage = sum(right_threshold_list) / pixel_count
    # this comment is necessary to suppress an unnecessary PyCharm warning
    # noinspection PyTypeChecker
    right_variance = calculate_variance(right_threshold_list, pixel_count)

    return left_percentage * left_variance + right_percentage * right_variance


# Histogram background calculation based on threshold
def histogram_background(histogram, threshold):
    background_sum = 0
    threshold_sum = calculate_sum_threshold(histogram, threshold)

    for count in range(0, threshold):
        if 0 < threshold_sum < 1 and (histogram[count] / (1 - threshold_sum)) != 0:
            background_sum += (histogram[count] / threshold_sum) * log(histogram[count] / threshold_sum)

    return background_sum * (-1)


# Histogram foreground calculation based on threshold
def histogram_foreground(histogram, threshold):
    foreground_sum = 0
    threshold_sum = calculate_sum_threshold(histogram, threshold)

    for count in range(threshold, len(histogram)):
        if 0 < threshold_sum < 1 and (histogram[count] / (1 - threshold_sum)) != 0:
            foreground_sum += (histogram[count] / (1 - threshold_sum)) * log(histogram[count] / (1 - threshold_sum))

    return foreground_sum * (-1)


# Different thresholds for segmentations
def different_thresholds_segmentation_otsu(normalized_histogram, pixel_count, low, high):
    variance_list = list()
    for count in range(low, high):
        variance_list.append(calculate_variances_thresholds(normalized_histogram, count, pixel_count))
    minimal_variance = min(variance_list)
    print("Minimal variance: ", minimal_variance)

    optimal_threshold = 0
    for count in range(0, len(variance_list)):
        if minimal_variance == variance_list[count]:
            optimal_threshold = count
    print("Optimal threshold: ", optimal_threshold)

    return optimal_threshold


# Different thresholds for segmentation
def different_threshold_segmentation_kapur(normalized_histogram, low, high):
    threshold_list = list()
    for count in range(low, high):
        threshold_list.append((histogram_background(normalized_histogram, count))
                              + (histogram_foreground(normalized_histogram, count)))
    maximum_threshold = max(threshold_list)
    print("Maximum variance: ", maximum_threshold)

    optimal_threshold = 0
    for count in range(0, len(threshold_list)):
        if maximum_threshold == threshold_list[count]:
            optimal_threshold = count
    print("Optimal threshold: ", optimal_threshold)
    return optimal_threshold


# Modify image for segmentation
def modify_image_segmentation(name, optimal_threshold):
    binary_image = np.zeros(segmentation_image.shape, np.uint8)

    x = 0
    for row in segmentation_image:
        y = 0
        for pixel in row:
            if pixel >= optimal_threshold:
                binary_image[x][y] = 255
            y += 1
        x += 1
    cv.imshow(name + str(optimal_threshold), binary_image)
    return binary_image


# Otsu segmentation function
def otsu_segmentation():
    global segmentation_image
    pixel_count = segmentation_image.shape[0] * segmentation_image.shape[1]

    histogram = make_histogram(segmentation_image)
    normalized_histogram = make_normalized_histogram(histogram, pixel_count)

    optimal_threshold_all = different_thresholds_segmentation_otsu(normalized_histogram, pixel_count, 1, 256)
    optimal_threshold_small = different_thresholds_segmentation_otsu(normalized_histogram, pixel_count, 10, 100)
    optimal_threshold_middle = different_thresholds_segmentation_otsu(normalized_histogram, pixel_count, 50, 200)

    modify_image_segmentation("Otsu segmentation", optimal_threshold_all)
    modify_image_segmentation("Otsu segmentation", optimal_threshold_middle)
    modify_image_segmentation("Otsu segmentation", optimal_threshold_small)


# Kapur segmentation function
def kapur_segmentation():
    global segmentation_image
    pixel_count = segmentation_image.shape[0] * segmentation_image.shape[1]

    histogram = make_histogram(segmentation_image)
    normalized_histogram = make_normalized_histogram(histogram, pixel_count)

    optimal_threshold_all = different_threshold_segmentation_kapur(normalized_histogram, 1, 256)
    optimal_threshold_small = different_threshold_segmentation_kapur(normalized_histogram, 10, 100)
    optimal_threshold_middle = different_threshold_segmentation_kapur(normalized_histogram, 50, 200)

    modify_image_segmentation("Kapur segmentation", optimal_threshold_all)
    modify_image_segmentation("Kapur segmentation", optimal_threshold_middle)
    modify_image_segmentation("Kapur segmentation", optimal_threshold_small)


window = Tk()
window.title("My first computer vision program")
window.configure(background="black", padx=20, pady=20)

# Creating the interface for the main program with buttons
photo1 = PhotoImage(file="images/computer_vision.png")
Label(window, image=photo1, bg="black").grid(row=0, column=0, columnspan=3)
Button(window, text="Load an image from disk", width=20, command=click_load_image) \
    .grid(row=1, column=0, sticky=N)
Button(window, text="Load a video from disk", width=20, command=click_load_video) \
    .grid(row=1, column=1, sticky=N)
Button(window, text="Open camera", width=20, command=click_load_camera) \
    .grid(row=1, column=2, sticky=N)
Label(window, bg="black").grid(row=2, column=0, columnspan=3)
Button(window, text="Open grayscale image filter", width=20, command=open_image_in_grayscale) \
    .grid(row=3, column=0, sticky=N)
Button(window, text="Segmentations", width=20, command=segmentation_graphical_interface) \
    .grid(row=3, column=1, sticky=N)
window.mainloop()

# Comments for the exercises
# Convolution, image filtering and edge detection

# 1. What happens if we change the noise reduction kernel size?
# By changing the size of the kernel, we are changing the intensity of the blurriness,
# bigger kernel size, bigger the blur and vise versa. By blurring the image we reduce the
# number of edges the canny algorithm can find and make it less effective in my eyes.

# 2. How does the neighborhood apply on the result in the last step?
# This part of the exercise i have not implemented, but i would guess that with more
# neighbors to choose from, we are giving the edges more of a chance to improve, meaning
# if we check 8 neighbors vs 2 neighbors, there is a bigger chance to find weak edges in that
# area

# 3. Based on a user Geerten answer on StackOverflow, there are a couple of points, which are
# limitations. When the result is binary and we need a measure of "how much" the edge qualifies
# as an edge. The amount of parameters leads to tweaking the algorithm infinitely for the "little
# better result". Also due to the smoothing, the location of the edges might be a bit off, dependent
# on the size of the smoothing kernel (gaussian, mean, ...). The Canny algorithm also has problems with
# corners and jurisdictions (smoothing blurs them out, harder to detect)
