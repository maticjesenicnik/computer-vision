# This is a first exercise for Computer Vision program
from tkinter import *
from tkinter import filedialog
import cv2 as cv


# key down functions
def click_load_image():
    path = filedialog.askopenfilename()
    img = cv.imread(path, 1)
    if img is None:
        print("Image was not selected")
    else:
        cv.setMouseCallback("Image preview", click_image)
        cv.imshow("Image preview", img)
        key = cv.waitKey(0)
        cv.destroyAllWindows()


# Didn't define the buttons and their functionalities, instead play and pause
# commence with a press of 'P'
def click_load_video():
    # x, y = 0, 0
    path = filedialog.askopenfilename()
    video = cv.VideoCapture(path)
    # play = True
    if video is None:
        print("Video was not selected")
    else:
        while video.isOpened():
            ret, frame = video.read()
            # cv.setMouseCallback("Video", click_image, param=[x, y])
            # if x >= 270 & x <= 310 & y >= 300 & y <= 340:
            #     play = False
            # if x >= 340 & x <= 380 & y >= 300 & y <= 340:
            #     play = True
            # back button
            cv.rectangle(frame, (20, 160), (60, 200), (211, 211, 211), -1)

            # pause button
            cv.rectangle(frame, (270, 300), (310, 340), (211, 211, 211), -1)
            cv.line(frame, (285, 310), (285, 330), (0, 0, 0), 3)
            cv.line(frame, (295, 310), (295, 330), (0, 0, 0), 3)

            # play button
            cv.rectangle(frame, (340, 300), (380, 340), (211, 211, 211), -1)
            cv.line(frame, (352, 310), (352, 330), (0, 0, 0), 3)
            cv.line(frame, (352, 310), (370, 320), (0, 0, 0), 3)
            cv.line(frame, (352, 330), (370, 320), (0, 0, 0), 3)
            # forward button
            cv.rectangle(frame, (580, 160), (620, 200), (211, 211, 211), -1)
            cv.imshow('Video', frame)
            key = cv.waitKey(25)
            # Close the video
            if key == ord('q'):
                break
            # Pause/Play video
            if key == ord('p'):
                cv.waitKey(0)
        video.release()
        cv.destroyAllWindows()


# Didn't define the buttons and their functionalities, instead saving starts and stops
# with a press of 'S'
def click_load_camera():
    camera = cv.VideoCapture(0, cv.CAP_DSHOW)
    width = int(camera.get(cv.CAP_PROP_FRAME_WIDTH) + 0.5)
    height = int(camera.get(cv.CAP_PROP_FRAME_HEIGHT) + 0.5)
    size = (width, height)
    fourcc = cv.VideoWriter_fourcc(*'XVID')
    saving = False
    out = cv.VideoWriter('camera_output.avi', fourcc, 20.0, size)
    if camera is None:
        print("Camera was not opened")
    if not camera.isOpened():
        print("Camera was not able to open")
    while camera.isOpened():
        ret, frame = camera.read()
        cv.imshow("Camera feed", frame)
        key = cv.waitKey(1)
        # Close the camera feed
        if key == ord('q'):
            break
        # Start/Stop saving
        if key == ord('s'):
            saving = not saving
        if saving:
            out.write(frame)
    camera.release()
    cv.destroyAllWindows()


def click_image(event, x, y, flags, param):
    if event == cv.EVENT_LBUTTONUP:
        param[0] = [x, y]


window = Tk()
window.title("My first computer vision program")
window.configure(background="black", padx=20, pady=20)

# Creating the interface for the main program with buttons
photo1 = PhotoImage(file="images/computer_vision.png")
Label(window, image=photo1, bg="black").grid(row=0, column=0, columnspan=3, sticky=W)
Button(window, text="Load an image from disk", width=20, command=click_load_image) \
    .grid(row=1, column=0, sticky=N)
Button(window, text="Load a video from disk", width=20, command=click_load_video) \
    .grid(row=1, column=1, sticky=N)
Button(window, text="Open camera", width=20, command=click_load_camera) \
    .grid(row=1, column=2, sticky=N)
window.mainloop()
