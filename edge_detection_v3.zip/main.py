# This is a first exercise for Computer Vision program
from tkinter import *
from tkinter import filedialog
from matplotlib import pyplot as plt
from PIL import Image, ImageStat
from math import sqrt, pow
import cv2 as cv
import numpy as np

# global variables
filter_image = None

# edge detection kernels
# Sobel kernels
sobel_horizontal_kernel = np.array([[-1, 0, 1],
                                    [-2, 0, 2],
                                    [-1, 0, 1]
                                    ])
sobel_vertical_kernel = np.array([[1, 2, 1],
                                  [0, 0, 0],
                                  [-1, -2, -1]
                                  ])
# Prewitt kernels
prewitt_horizontal_kernel = np.array([[-1, 0, 1],
                                      [-1, 0, 1],
                                      [-1, 0, 1]
                                      ])
prewitt_vertical_kernel = np.array([[-1, -1, -1],
                                    [0, 0, 0],
                                    [1, 1, 1]
                                    ])


# key down functions
def click_load_image():
    path = filedialog.askopenfilename()
    img = cv.imread(path, 1)
    if img is None:
        print("Image was not selected")
    else:
        cv.imshow("Image preview", img)
        key = cv.waitKey(0)
        cv.destroyAllWindows()


# Didn't define the buttons and their functionalities, instead play and pause
# commence with a press of 'P'
def click_load_video():
    # x, y = 0, 0
    path = filedialog.askopenfilename()
    video = cv.VideoCapture(path)
    # play = True
    if video is None:
        print("Video was not selected")
    else:
        while video.isOpened():
            ret, frame = video.read()
            # cv.setMouseCallback("Video", click_image, param=[x, y])
            # if x >= 270 & x <= 310 & y >= 300 & y <= 340:
            #     play = False
            # if x >= 340 & x <= 380 & y >= 300 & y <= 340:
            #     play = True
            # back button
            cv.rectangle(frame, (20, 160), (60, 200), (211, 211, 211), -1)

            # pause button
            cv.rectangle(frame, (270, 300), (310, 340), (211, 211, 211), -1)
            cv.line(frame, (285, 310), (285, 330), (0, 0, 0), 3)
            cv.line(frame, (295, 310), (295, 330), (0, 0, 0), 3)

            # play button
            cv.rectangle(frame, (340, 300), (380, 340), (211, 211, 211), -1)
            cv.line(frame, (352, 310), (352, 330), (0, 0, 0), 3)
            cv.line(frame, (352, 310), (370, 320), (0, 0, 0), 3)
            cv.line(frame, (352, 330), (370, 320), (0, 0, 0), 3)
            # forward button
            cv.rectangle(frame, (580, 160), (620, 200), (211, 211, 211), -1)
            cv.imshow('Video', frame)
            key = cv.waitKey(25)
            # Close the video
            if key == ord('q'):
                break
            # Pause/Play video
            if key == ord('p'):
                cv.waitKey(0)
        video.release()
        cv.destroyAllWindows()


# Didn't define the buttons and their functionalities, instead saving starts and stops
# with a press of 'S'
def click_load_camera():
    camera = cv.VideoCapture(0, cv.CAP_DSHOW)
    width = int(camera.get(cv.CAP_PROP_FRAME_WIDTH) + 0.5)
    height = int(camera.get(cv.CAP_PROP_FRAME_HEIGHT) + 0.5)
    size = (width, height)
    fourcc = cv.VideoWriter_fourcc(*'XVID')
    saving = False
    out = cv.VideoWriter('camera_output.avi', fourcc, 20.0, size)
    if camera is None:
        print("Camera was not opened")
    if not camera.isOpened():
        print("Camera was not able to open")
    while camera.isOpened():
        ret, frame = camera.read()
        cv.imshow("Camera feed", frame)
        key = cv.waitKey(1)
        # Close the camera feed
        if key == ord('q'):
            break
        # Start/Stop saving
        if key == ord('s'):
            saving = not saving
            print("Saving" if saving else "Stopping saving")
        if saving:
            out.write(frame)
    camera.release()
    cv.destroyAllWindows()


def is_greyscale(img_path):
    image = Image.open(img_path).convert("RGB")
    stat = ImageStat.Stat(image)
    if sum(stat.sum) / 3 == stat.sum[0]:
        return True
    else:
        return False


def open_image_in_grayscale():
    global filter_image
    cv.destroyAllWindows()
    camera = cv.VideoCapture(1, cv.CAP_DSHOW)
    ret, filter_image = camera.read()
    cv.imwrite('NewPicture.jpg', filter_image)
    camera.release()
    filter_image = cv.cvtColor(filter_image, cv.COLOR_BGR2GRAY)
    cv.imshow("Original picture", filter_image)
    open_edge_detection_filters()


def apply_edge_detection(image, horizontal_kernel, vertical_kernel):
    image_pixels = np.zeros(image.shape, np.uint8)

    horizontal_filtering = np.zeros(image.shape, np.uint8)
    vertical_filtering = np.zeros(image.shape, np.uint8)

    height, width = image.shape

    for x in range(1, height - 1):
        for y in range(1, width - 1):
            horizontal_filtering[x][y] = np.absolute((
                    horizontal_kernel[0][0] * image[x - 1][y - 1] +
                    horizontal_kernel[1][0] * image[x][y - 1] +
                    horizontal_kernel[2][0] * image[x + 1][y - 1] +
                    horizontal_kernel[0][2] * image[x - 1][y + 1] +
                    horizontal_kernel[1][2] * image[x][y + 1] +
                    horizontal_kernel[2][2] * image[x + 1][y + 1]
            ))
            vertical_filtering[x][y] = np.absolute((
                    vertical_kernel[0][0] * image[x - 1][y - 1] +
                    vertical_kernel[0][1] * image[x - 1][y] +
                    vertical_kernel[0][2] * image[x - 1][y + 1] +
                    vertical_kernel[2][0] * image[x + 1][y - 1] +
                    vertical_kernel[2][1] * image[x + 1][y] +
                    vertical_kernel[2][2] * image[x + 1][y + 1]
            ))

            image_pixels[x][y] = sqrt(pow(vertical_filtering[x][y], 2) + pow(horizontal_filtering[x][y], 2))

    # Display the images with the filters
    cv.imshow("Horizontal filtering", horizontal_filtering)
    cv.imshow("Vertical filtering", vertical_filtering)
    cv.imshow("Filtered image", image_pixels)


def open_edge_detection_filters():
    filters = Tk()
    filters.title("Filtering")
    filters.configure(background="black", padx=20, pady=20)
    # Buttons for edge detection
    Label(filters, text="Filters", bg="black", fg="white").grid(row=0, column=0)
    Button(filters, text="Sobel", width=30, command=sobel_filter) \
        .grid(row=1, column=0, sticky=N)
    Button(filters, text="Prewitt", width=30, command=prewitt_filter) \
        .grid(row=2, column=0, sticky=N)
    filters.mainloop()


def sobel_filter():
    global filter_image, sobel_horizontal_kernel, sobel_vertical_kernel
    apply_edge_detection(filter_image, sobel_horizontal_kernel, sobel_vertical_kernel)


def prewitt_filter():
    global filter_image, prewitt_horizontal_kernel, prewitt_vertical_kernel
    apply_edge_detection(filter_image, prewitt_horizontal_kernel, prewitt_vertical_kernel)

# # Loading an image and calculating histograms
# def click_calculate_histograms():
#     path = filedialog.askopenfilename()
#     img = cv.imread(path, 1)
#     height, width, channels = img.shape
#     print(img.shape)
#     if img is None:
#         print("Image was not selected")
#     else:
#         cv.imshow("Image preview", img)
#         if is_greyscale(path):
#             print("Here:")
#             array = []
#             for j in range(width):
#                 for i in range(height):
#                     # array[img[i][j][0]] = array[img[i][j][0]] + 1
#                     np.append(array, [img[i][j][0]])
#             plt.hist([array], 256, [0, 256])
#             plt.show()
#         else:
#             red = [int]*256
#             blue = [int]*256
#             green = [int]*256
#             for i in range(256):
#                 red[i], blue[i], green[i] = 0, 0, 0
#             print("width: {}, height: {}".format(width, height))
#             for j in range(width):
#                 for i in range(height):
#                     # print("Width: {}, Height: {}".format(i, j))
#                     red[img[i][j][2]] = red[img[i][j][2]] + 1
#                     blue[img[i][j][0]] = blue[img[i][j][0]] + 1
#                     green[img[i][j][1]] = green[img[i][j][1]] + 1
#             plt.hist(np.array(green), bins=[0, 256])
#             plt.hist(img.ravel(), 256, [0, 256])
#             plt.show()
#
#         key = cv.waitKey(0)
#         cv.destroyAllWindows()


window = Tk()
window.title("My first computer vision program")
window.configure(background="black", padx=20, pady=20)

# Creating the interface for the main program with buttons
photo1 = PhotoImage(file="images/computer_vision.png")
Label(window, image=photo1, bg="black").grid(row=0, column=0, columnspan=3)
Button(window, text="Load an image from disk", width=20, command=click_load_image) \
    .grid(row=1, column=0, sticky=N)
Button(window, text="Load a video from disk", width=20, command=click_load_video) \
    .grid(row=1, column=1, sticky=N)
Button(window, text="Open camera", width=20, command=click_load_camera) \
    .grid(row=1, column=2, sticky=N)
# Button(window, text="Load an image and calculate histogram", command=click_calculate_histograms) \
#     .grid(row=1, column=3, sticky=N)
Label(window, bg="black").grid(row=2, column=0, columnspan=3)
Button(window, text="Open grayscale image filter", width=20, command=open_image_in_grayscale) \
    .grid(row=3, column=0, sticky=N)
window.mainloop()
